@extends('layouts.admin-layouts')
@section('title', 'Format Layout')

@push('css')
    {{-- CSS Code Here --}}
@endpush

@section('main-header', 'Format Layout')

@section('main-content')
    
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <p>Format Layout</p>
            </div>
        </div>
    </div>

@endsection

@push('js')
    {{-- JS Code Here --}}
@endpush