<div>
    <?php $__env->startPush('css'); ?>
    <style>
        .modal-backdrop.show {
            display: none !important;
        }
        .fix-text {
            font-size: 15px;
        }
        .fix-text-h5 {
            font-size: 3px;
        }
        table.dataTable tbody th,
        table.dataTable tbody td {
            padding: 6px 8px!important;
            border-color: #d8d8d8!important;
            border-top-color: #d8d8d8!important;
            border-right-color: #d8d8d8!important;
            border-bottom-color: #d8d8d8!important;
            border-left-color: #d8d8d8!important;
            table-layout:fixed!important;
            white-space: nowrap!important;
        }
        .button-text-fix {
            font-size: 11px!important;
        }
        table.dataTable {
            color: rgb(0, 0, 0)!important;
        }
    </style>
    <?php $__env->stopPush(); ?>
    
    <div class="modal fade" id="modaltambahpeserta" tabindex="1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Tambah Data Pelaksana</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                
                <form action="<?php echo e(route('post-tambah-pelaksana')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="container border-dark mt-3">

                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="login_nama">Nama Lengkap : </label>
                                    <input type="text" class="form-control" id="login_nama"
                                        placeholder="Masukkan nama lengkap" name="login_nama">
                                    <small id="login_nama" class="form-text text-muted">Contoh : Muh. Khairy Keenan
                                    </small>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="login_email">Email : </label>
                                    <input type="email" class="form-control" id="login_email"
                                        placeholder="Masukkan Email" name="login_email">
                                    
                                    </small>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="login_username">Username : </label>
                                    <input type="username" class="form-control" id="login_username"
                                        placeholder="Masukkan Email" name="login_username">
                                    
                                    </small>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="login_telepon">No. HP / Telepon : </label>
                                    <input type="number" class="form-control" id="login_telepon"
                                        placeholder="Masukkan No. HP / Telepon" name="login_telepon">
                                    
                                    </small>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn gray btn-danger" data-dismiss="modal">Batalkan</button>
                        <button type="submit" class="btn btn-info">
                            Tambah
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-sddtik\resources\views/components/modal-tambah-pelaksana.blade.php ENDPATH**/ ?>