<?php $__env->startSection('title', 'Deteksi Dini Penyimpangan Mental Emosional'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Deteksi Dini Penyimpangan Mental Emosional'); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="row">

        <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>KMPE </b></h5>
                    <p class="card-text">Kuesioner Masalah Perilaku Emosional </p>
                    <a href="<?php echo e(route('kmpe')); ?>" class="btn btn-info"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>M-CHAT </b></h5>
                    <p class="card-text mb-2">Modified Checklist for Autism in Toddlers </p>
                    <a href="<?php echo e(route('mchat')); ?>" class="btn btn-info mt-3"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>GPPH </b></h5>
                    <p class="card-text mb-2">Gangguan Pemusatan Perhatian dan Hiperaktivitas </p>
                    <a href="<?php echo e(route('gpph')); ?>" class="btn btn-info mt-3"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-sddtik\resources\views/pelayanan/deteksi-penyimpangan-mental-emosional.blade.php ENDPATH**/ ?>