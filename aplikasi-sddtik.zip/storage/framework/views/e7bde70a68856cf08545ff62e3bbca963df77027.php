<?php $__env->startSection('title', 'Tes Daya Dengar'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Tes Daya Dengar'); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container">

        <form action="<?php echo e(route('post-tdd')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col-sm-8 col-md-8 col-lg-8">
                    <div class="form-group">
                        <label for="exampleSelectGender">
                            1. Kemampuan Ekpresif <br />
                            Apakah anak mulai menggunakan kata-kata lain, selain kata mama, papa, anggota keluarga lain dan hewan peliharaan? <br />
                            Apakah anak mulai mengungkapkan kata yang berarti "milik" misal "susu kamu", "bonekaku"?
                        </label>
                        <select class="form-control" id="exampleSelectGender" name="jawaban_tdd[]">
                            <option selected value="">Pilih jawaban...</option>
                            <option value="YA">YA</option>
                            <option value="TIDAK">TIDAK</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-8 col-md-8 col-lg-8">
                    <div class="form-group">
                        <label for="exampleSelectGender">
                            1. Kemampuan Reseptif <br />
                            Apakah anak dapat mengerjakan 2 macam perintah dalam satu kalimat, seperti ambil sepatu dan taruh disini, tanpa diberi contoh ? <br />
                            Apakah anak dapat menunjuk minimal 2 nama benda didepannya (cangkir, bola, sendok) ?
                        </label>
                        <select class="form-control" id="exampleSelectGender" name="jawaban_tdd[]">
                            <option selected value="">Pilih jawaban...</option>
                            <option value="YA">YA</option>
                            <option value="TIDAK">TIDAK</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-8 col-md-8 col-lg-8">
                    <div class="form-group">
                        <label for="exampleSelectGender">
                            1. Kemampuan Visual <br />
                            Apakah anak secara spontan memulai permainan dengan gerakan tubuh, seperti pok ame-ame atau cilukba ?<br />
                            Apakah anak anda menunjuk dengan jari telunjuk bila ingin sesuatu, bukan dengan cara memegang tangan semua jari ?
                        </label>
                        <select class="form-control" id="exampleSelectGender" name="jawaban_tdd[]">
                            <option selected value="">Pilih jawaban...</option>
                            <option value="YA">YA</option>
                            <option value="TIDAK">TIDAK</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 col-md-4 col-lg-4">
                    <div class="form-group">
                        <button class="btn btn-info btn-md" type="submit">
                            PROSES
                        </button>
                    </div>
                </div>
            </div>

        </form>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-sddtik\resources\views/pelayanan/tdd.blade.php ENDPATH**/ ?>