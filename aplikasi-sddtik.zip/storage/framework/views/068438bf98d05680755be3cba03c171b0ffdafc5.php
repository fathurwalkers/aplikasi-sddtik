<?php $__env->startSection('title', 'Berat Badan / Tinggi Badan'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Berat Badan / Tinggi Badan'); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container">
        <form action="<?php echo e(route('post-bbtb')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-8 col-md-8 col-lg-8">
                    <div class="form-group">
                        <label for="exampleSelectGender">Masukkan Berat Badan saat ini : </label>
                        <input type="number" class="form-control" step="any" name="jawaban_bb">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-8 col-md-8 col-lg-8">
                    <div class="form-group">
                        <label for="exampleSelectGender">Masukkan Tinggi Badan saat ini : </label>
                        <input type="number" class="form-control" step="any" name="jawaban_tb">
                    </div>
                </div>
            </div>
            <div class="row">
                <button type="submit" class="btn btn-md btn-info">
                    Proses
                </button>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-sddtik\resources\views/pelayanan/bbtb.blade.php ENDPATH**/ ?>