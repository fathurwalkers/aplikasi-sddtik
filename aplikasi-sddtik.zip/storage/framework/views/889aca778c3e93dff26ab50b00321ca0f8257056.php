<?php $__env->startSection('title', 'Deteksi Dini Penyimpangan Perkembangan'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Deteksi Dini Penyimpangan Perkembangan'); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="row group">

        <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>KPSP </b></h5>
                    <p class="card-text">Kuesioner Pra Skrining Perkembangan</p>
                    <a href="<?php echo e(route('kpsp')); ?>" class="btn btn-info"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>TDD </b></h5>
                    <p class="card-text mb-2">Tes Daya Dengar</p>
                    <a href="<?php echo e(route('tdd')); ?>" class="btn btn-info mt-3"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>TDL</b></h5>
                    <p class="card-text mb-2">Tes Daya Lihat</p>
                    <a href="<?php echo e(route('tdl')); ?>" class="btn btn-info mt-3"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-sddtik\resources\views/pelayanan/deteksi-penyimpangan-perkembangan.blade.php ENDPATH**/ ?>