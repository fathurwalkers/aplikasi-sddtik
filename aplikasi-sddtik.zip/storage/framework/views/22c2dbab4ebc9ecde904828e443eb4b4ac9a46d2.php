<?php $__env->startSection('title', 'Deteksi Dini Penyimpangan Pertumbuhan'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Deteksi Dini Penyimpangan Pertumbuhan'); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="row group">

        <div class="col-sm-6 col-md-6 col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>BB/TB</b></h5>
                    <p class="card-text">Berat Badan Terhadap Tinggi Badan</p>
                    <a href="<?php echo e(route('bbtb')); ?>" class="btn btn-info"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-6 col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>LK</b></h5>
                    <p class="card-text mb-2">Lingkar Kepala</p>
                    <a href="<?php echo e(route('lk')); ?>" class="btn btn-info mt-3"><b>Mulai Tes ></b></a>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-sddtik\resources\views/pelayanan/deteksi-penyimpangan-pertumbuhan.blade.php ENDPATH**/ ?>