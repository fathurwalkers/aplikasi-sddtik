<?php $__env->startSection('title', 'Data Pelaksana'); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <style>
        .cke {
            visibility: visible !important;
        }

        .modal-backdrop.show {
            display: none !important;
        }

        .fix-text {
            font-size: 15px;
        }

        .fix-text-h5 {
            font-size: 12px;
        }

        table.dataTable tbody th,
        table.dataTable tbody td {
            padding: 6px 8px !important;
            border-color: #d8d8d8 !important;
            border-top-color: #d8d8d8 !important;
            border-right-color: #d8d8d8 !important;
            border-bottom-color: #d8d8d8 !important;
            border-left-color: #d8d8d8 !important;
            table-layout: fixed !important;
            white-space: nowrap !important;
        }

        .button-text-fix {
            font-size: 11px !important;
        }

        table.dataTable {
            color: rgb(0, 0, 0) !important;
        }

        .fixed-text-th {
            font-size: 15px !important;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Data Pelaksana'); ?>

<?php $__env->startSection('status-pelayanan'); ?>
    <a href="#" class="btn btn-md btn-info" data-toggle="modal" data-target="#modaltambahpeserta">
        <b>Tambah Pelaksana</b>
    </a>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal-tambah-pelaksana','data' => []]); ?>
<?php $component->withName('modal-tambah-pelaksana'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    &nbsp;
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container">

        
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        ERROR : Ada data yang tidak isi.
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="table-responsive">
                    <table id="example1" class="table table-bordered" style="width:100%">
                        <thead>
                            <tr class="">
                                <th class="fixed-text-th">No</th>
                                <th class="fixed-text-th">Nama Lengkap</th>
                                <th class="fixed-text-th">Username</th>
                                <th class="fixed-text-th">Akses Level</th>
                                <th class="fixed-text-th">Email</th>
                                <th class="fixed-text-th">No. HP / Telepon</th>
                                <th class="fixed-text-th">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->login_nama); ?></td>
                                    <td><?php echo e($item->login_username); ?></td>
                                    <td><?php echo e(strtoupper($item->login_level)); ?></td>
                                    <td><?php echo e($item->login_email); ?></td>
                                    <td><?php echo e($item->login_telepon); ?></td>
                                    <td>
                                        

                                        <button class="btn btn-danger btn-lg" type="button" data-toggle="modal"
                                            data-target="#modaldelete<?php echo e($item->id); ?>">
                                            HAPUS
                                        </button>

                                        
                                        <div class="modal fade" id="modaldelete<?php echo e($item->id); ?>" tabindex="1"
                                            role="dialog" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">

                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Konfirmasi Tindakan</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>

                                                    <div class="modal-body">Apakah anda yakin ingin menghapus peserta
                                                        ini?
                                                    </div>
                                                    <form action="<?php echo e(route('hapus-pelaksana', $item->id)); ?>" method="POST"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn gray btn-outline-secondary"
                                                                data-dismiss="modal">BATALKAN</button>
                                                            <button type="submit" class="btn btn-outline-danger">
                                                                YA, HAPUS
                                                            </button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                        

                                        
                                        <div class="modal fade" id="modalupdate<?php echo e($item->id); ?>" tabindex="1" role="dialog"
                                            aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">

                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Ubah Data Peserta</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>

                                                    <div class="modal-body">Silahkan ubah data peserta berikut. </div>
                                                    <form action="<?php echo e(route('post-update-peserta', $item->id)); ?>" method="POST"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>

                                                        <div class="container border-dark">

                                                            <div class="row">
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_nama">Nama Lengkap</label>
                                                                        <input type="text" class="form-control"
                                                                            id="detail_nama"
                                                                            placeholder="Masukkan merk kendaraan"
                                                                            name="detail_nama" value="<?php echo e($item->detail_nama); ?>">
                                                                        <small id="detail_nama"
                                                                            class="form-text text-muted">Contoh : Muh.
                                                                            Keenan
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_nik">NIK</label>
                                                                        <input type="number" class="form-control"
                                                                            id="detail_nik" placeholder="Masukkan NIK"
                                                                            name="detail_nik" value="<?php echo e($item->detail_nik); ?>">
                                                                        
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_ttl">Tanggal Lahir</label>
                                                                        <input type="date" class="form-control"
                                                                            id="detail_ttl"
                                                                            placeholder="Masukkan Tanggal Lahir"
                                                                            name="detail_ttl" value="<?php echo e(date("d/m/Y", strtotime($item->detail_ttl))); ?>">
                                                                        
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_jeniskelamin">Jenis
                                                                            Kelamin</label>
                                                                        <select id="detail_jeniskelamin"
                                                                            class="form-control"
                                                                            name="detail_jeniskelamin">
                                                                            <option value="<?php echo e($item->detail_jeniskelamin); ?>" selected><?php echo e($item->detail_jeniskelamin); ?>

                                                                            </option>
                                                                            <option value="L">Laki-Laki</option>
                                                                            <option value="P">Perempuan</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_nama_ayah">Nama Ayah</label>
                                                                        <input type="text" class="form-control"
                                                                            id="detail_nama_ayah"
                                                                            placeholder="Masukkan nama ayah"
                                                                            name="detail_nama_ayah" value="<?php echo e($item->detail_nama_ayah); ?>">
                                                                        
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_nama_ibu">Nama Ibu</label>
                                                                        <input type="text" class="form-control"
                                                                            id="detail_nama_ibu"
                                                                            placeholder="Masukkan nama ibu"
                                                                            name="detail_nama_ibu" value="<?php echo e($item->detail_nama_ibu); ?>">
                                                                        
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-sm-12 col-md-12 col-lg-12">
                                                                    <div class="form-group">
                                                                        <label for="detail_alamat">Alamat</label>
                                                                        <input type="text" class="form-control"
                                                                            id="detail_alamat" placeholder="Masukkan Alamat"
                                                                            name="detail_alamat" value="<?php echo e($item->detail_alamat); ?>">
                                                                        
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_berat_badan_lahir">Berat Badan
                                                                            Lahir (kg)</label>
                                                                        <input type="number" class="form-control"
                                                                            id="detail_berat_badan_lahir"
                                                                            placeholder="Masukkan Beran badan lahir"
                                                                            name="detail_berat_badan_lahir" value="<?php echo e($item->detail_berat_badan_lahir); ?>">
                                                                        
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="detail_tinggi_badan_lahir">Tinggi Badan
                                                                            Lahir (cm)</label>
                                                                        <input type="number" class="form-control"
                                                                            id="detail_tinggi_badan_lahir"
                                                                            placeholder="Masukkan Beran badan lahir"
                                                                            name="detail_tinggi_badan_lahir" value="<?php echo e($item->detail_tinggi_badan_lahir); ?>">
                                                                        
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-sm-12 col-md-12 col-lg-12">
                                                                    <div class="form-group">
                                                                        <label for="detail_riwayat_persalinan">Riwayat
                                                                            Persalinan</label>
                                                                        <select id="detail_riwayat_persalinan"
                                                                            class="form-control"
                                                                            name="detail_riwayat_persalinan">
                                                                            <option value="<?php echo e($item->detail_riwayat_persalinan); ?>" selected><?php echo e($item->detail_riwayat_persalinan); ?>"</option>
                                                                            <option value="ATERM">ATERM</option>
                                                                            <option value="PREMATUR">PREMATUR</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                        <div class="modal-footer">
                                                            <button type="button" class="btn gray btn-danger"
                                                                data-dismiss="modal">Batalkan</button>
                                                            <button type="submit" class="btn btn-info">
                                                                Ubah
                                                            </button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous">
    </script>
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#example1').DataTable();
            // let table = new DataTable('#example1', {
            //     // options
            // });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-sddtik\resources\views/admin/data-pelaksana.blade.php ENDPATH**/ ?>